class UTS_1{
	public static void main(String args[]){
		System.out.println("*** Program menentukan minimal lembar mata uang yang dikeluarkan ***");
		System.out.println("NIM  : 123456");
		System.out.println("Nama : Zawa");
		System.out.println("--------------------\n");
		System.out.println(">> Mulai");
		System.out.println("Masukkan nominal uang : ");
		System.out.println("--------------------\n");
		System.out.println(">> Hasil");
		System.out.println("Lembar uang 100.000 : 1");
		System.out.println("Lembar uang 50.000 : 0");
		System.out.println("Lembar uang 20.000 : 1");
		System.out.println("Lembar uang 10.000 : 1");
		System.out.println("Lembar uang 5.000 : 1");
		System.out.println("Lembar uang 2.000 : 1");
		System.out.println("Lembar uang 1.000 : 0");
		System.out.println("Selesai <<<");
	}
}